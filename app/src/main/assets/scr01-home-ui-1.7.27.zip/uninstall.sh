#!/system/bin/sh

TARGET_APK=/system/priv-app/MHSHome/MHSHome.apk
HOME_PACKAGE=com.samsung.android.mhshome
HOME_COMPONENT=com.samsung.android.mhshome/.MainActivity
NSENTER=/system/bin/nsenter
TIMEOUT=/system/bin/timeout
FLOCK=/system/bin/flock
LOCK_FILE=/data/adb/.scr01_scroot_menu.activation.lock
EXPECTED_STOCK_SHA256=d69adf660a95ff156b02ff2f08e52c0c4acf0bdbb5fa8c3b7c5dd48b96138d45
EXPECTED_PATCH_SHA256=bb226a5f4b7b2fe86b6f24870798a25c605fa123b4d578a69db51c4d50adf1bd
UNMOUNTED=0
LOCK_HELD=0

acquire_activation_lock() {
    [ -x "$FLOCK" ] || return 1
    [ ! -L "$LOCK_FILE" ] || return 1
    [ ! -e "$LOCK_FILE" ] || [ -f "$LOCK_FILE" ] || return 1
    : >> "$LOCK_FILE" || return 1
    chmod 0600 "$LOCK_FILE" || return 1
    exec 0<> "$LOCK_FILE" || return 1
    count=0
    while ! "$FLOCK" -n 0; do
        count=$((count + 1))
        if [ "$count" -ge 1200 ]; then
            exec 0< /dev/null
            return 1
        fi
        sleep 0.1
    done
    LOCK_HELD=1
}

release_activation_lock() {
    if [ "$LOCK_HELD" = 1 ]; then
        "$FLOCK" -u 0 2>/dev/null || true
        exec 0< /dev/null
        LOCK_HELD=0
    fi
}

handle_uninstall_signal() {
    trap - HUP INT TERM
    exit 99
}

cleanup_on_exit() {
    cleanup_rc=$?
    trap - EXIT HUP INT TERM
    release_activation_lock
    exit "$cleanup_rc"
}

if ! acquire_activation_lock; then
    exit 90
fi
trap cleanup_on_exit EXIT
trap handle_uninstall_signal HUP INT TERM

home_pid() {
    home_pids=$(pidof "$HOME_PACKAGE" 2>/dev/null)
    home_result=
    home_count=0
    for home_candidate in $home_pids; do
        case "$home_candidate" in
            ''|*[!0-9]*) continue ;;
        esac
        home_name=$({
            tr '\000' '\n' < "/proc/$home_candidate/cmdline"
        } 2>/dev/null | sed -n '1p')
        [ "$home_name" = "$HOME_PACKAGE" ] || continue
        home_count=$((home_count + 1))
        [ "$home_count" -eq 1 ] || return 1
        home_result=$home_candidate
    done
    [ "$home_count" -eq 1 ] && [ -n "$home_result" ] || return 1
    printf '%s\n' "$home_result"
}

[ -x "$TIMEOUT" ] && [ -x "$NSENTER" ] || exit 91
mounted_hash=$(
    "$NSENTER" -t 1 -m -- "$TIMEOUT" -k 1s 15s \
        sha256sum "$TARGET_APK" 2>/dev/null | cut -d ' ' -f 1
)
case "$mounted_hash" in
    "$EXPECTED_PATCH_SHA256")
        if ! "$NSENTER" -t 1 -m -- "$TIMEOUT" -k 1s 10s \
            umount "$TARGET_APK" >/dev/null 2>&1 &&
            ! "$NSENTER" -t 1 -m -- "$TIMEOUT" -k 1s 10s \
                umount -l "$TARGET_APK" >/dev/null 2>&1; then
            exit 92
        fi
        UNMOUNTED=1
        restored_hash=$(
            "$NSENTER" -t 1 -m -- "$TIMEOUT" -k 1s 15s \
                sha256sum "$TARGET_APK" 2>/dev/null | cut -d ' ' -f 1
        )
        [ "$restored_hash" = "$EXPECTED_STOCK_SHA256" ] || exit 93
        ;;
    "$EXPECTED_STOCK_SHA256") ;;
    "") exit 94 ;;
    *) exit 95 ;;
esac

RESTART_REQUIRED=$UNMOUNTED
[ "$(getprop sys.boot_completed)" = 1 ] && RESTART_REQUIRED=1
if [ "$RESTART_REQUIRED" = 1 ]; then
    old_home_pid=$(home_pid) || old_home_pid=
    "$TIMEOUT" -k 1s 8s am force-stop "$HOME_PACKAGE" >/dev/null 2>&1 || exit 96
    "$TIMEOUT" -k 1s 12s am start \
        -a android.intent.action.MAIN -c android.intent.category.HOME \
        -n "$HOME_COMPONENT" >/dev/null 2>&1 || exit 97
    count=0
    new_home_pid=
    while [ "$count" -lt 60 ]; do
        new_home_pid=$(home_pid) || new_home_pid=
        if [ -n "$new_home_pid" ] &&
            { [ -z "$old_home_pid" ] || [ "$new_home_pid" != "$old_home_pid" ]; }; then
            break
        fi
        sleep 0.25
        count=$((count + 1))
    done
    [ -n "$new_home_pid" ] &&
        { [ -z "$old_home_pid" ] || [ "$new_home_pid" != "$old_home_pid" ]; } || exit 98
fi

exit 0
