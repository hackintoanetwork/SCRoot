#!/system/bin/sh

EXPECTED_DEVICE=SCR01
TARGET_APK=/system/priv-app/MHSHome/MHSHome.apk
PATCHER="$MODPATH/bin/scbspatch"
PATCH_FILE="$MODPATH/patch/MHSHome.bsdiff"
SCROOT_PACKAGE=com.scr01.scroot
BRIDGE_PACKAGE=com.sec.android.app.launcher
TIMEOUT=/system/bin/timeout
EXPECTED_STOCK_SHA256=d69adf660a95ff156b02ff2f08e52c0c4acf0bdbb5fa8c3b7c5dd48b96138d45
EXPECTED_PATCH_SHA256=bb226a5f4b7b2fe86b6f24870798a25c605fa123b4d578a69db51c4d50adf1bd
EXPECTED_PATCHER_SHA256=50688c893eab8fcf73277590f1b0486f1ba4a63431f568296ddbd864864d3089
EXPECTED_DELTA_SHA256=18fb9cd306d221841c322d29470d4d0a9efd1be984e008e679e4d3868f581cbb
EXPECTED_BRIDGE_SHA256=e21c90ee1c70c0a3134f532e179bef1cdaaa47105f63fbce4ca850596607258d

ui_print "- Checking SCR-01 home compatibility"

if [ ! -x "$TIMEOUT" ]; then
    abort "! Required timeout runtime is unavailable"
fi

device_name=$(getprop ro.product.device)
if [ "$device_name" != "$EXPECTED_DEVICE" ]; then
    abort "! Unsupported device: $device_name"
fi

if [ ! -f "$TARGET_APK" ]; then
    abort "! Stock MHSHome APK is missing"
fi

home_hash=$(sha256sum "$TARGET_APK" 2>/dev/null | cut -d ' ' -f 1)
case "$home_hash" in
    "$EXPECTED_STOCK_SHA256"|"$EXPECTED_PATCH_SHA256")
        ;;
    8a4362a3012ea44b1a50e3d29b3cebf9f6e16bd2e7b91e20585538219af0283c|\
    524007eeda1460e4df014e377b7e9bb57e6b316a0545fed9ccfc173e3ac0a024|\
    1b6584a705949f592964dc027b2414e7af59ef156748ac93868ad6af5cf9d880|\
    ce7659450509b47458eaaeb0c46dfe3157c6d11cc18f1f2b144c2d16b0d4928e|\
    32cca4a9b41cdbe38bb136decfec6b46b76d6a628613d6a755f0455631eb0d10|\
    ccbf69decb7ffde2bbe768f52aed90945b30069f6a9c952349cded3ed1d26f45|\
    fbea1f8f8bc3d27060baa1fc9aaada8926933cf0f74ff5f147fbb0eba7747c6b|\
    0c9f76b68adde3d14ac54d653b20405e8c71728c247dd6842ad149bea724636a|\
    ab1803ea431d5b1c04241264cb739df9e94da31fe7a5a096a6226158ea0c67f2|\
    ad9ad032d08e5023eb6b51ba71c740e822d0efe83d168e29fb71fec364c71fa8|\
    031554099fd69d95ef5bb3580721bed26e2a4cef06d3a9487006414a2397e4bf|\
    dcf7d3966caf426893270e669b0e9ecf760e8d956b8d9542c263fc341b5636c9|\
    afd5529ec9b469484d56c35ae262d4ecfabfc8f6537fa60fdf109675dc09ea60|\
    abb5ae74eb28fa535e44128df1b66865d4788795cb3ee925c04df0a179c1e912|\
    2fa44dca4260679ebbf1f8e661ed2444d677b232b32c300a83c6ba5e8145488c|\
    77b3c5617775a3df239a2ffdeb2e90282b292b8020d8a6f53216cae200e16c18)
        ui_print "- Previous live menu patch detected"
        ;;
    *)
        abort "! Unsupported MHSHome build: $home_hash"
        ;;
esac

if [ ! -f "$PATCHER" ] || [ ! -f "$PATCH_FILE" ]; then
    abort "! On-device Home patch generator is missing"
fi

patcher_hash=$(sha256sum "$PATCHER" 2>/dev/null | cut -d ' ' -f 1)
delta_hash=$(sha256sum "$PATCH_FILE" 2>/dev/null | cut -d ' ' -f 1)
if [ "$patcher_hash" != "$EXPECTED_PATCHER_SHA256" ]; then
    abort "! Home patch generator hash mismatch: $patcher_hash"
fi
if [ "$delta_hash" != "$EXPECTED_DELTA_SHA256" ]; then
    abort "! Home delta hash mismatch: $delta_hash"
fi
chmod 0755 "$PATCHER" || abort "! Home patch generator is not executable"

single_package_path() {
    package_name=$1
    package_paths=$("$TIMEOUT" -k 1s 10s pm path "$package_name" 2>/dev/null) ||
        return 1
    package_path=
    package_count=0
    while IFS= read -r package_line; do
        case "$package_line" in
            package:*)
                package_candidate=${package_line#package:}
                [ -n "$package_candidate" ] || return 1
                package_count=$((package_count + 1))
                [ "$package_count" -eq 1 ] || return 1
                package_path=$package_candidate
                ;;
            "") ;;
            *) return 1 ;;
        esac
    done <<EOF
$package_paths
EOF
    [ "$package_count" -eq 1 ] && [ -n "$package_path" ] || return 1
    printf '%s\n' "$package_path"
}

scroot_path=$(single_package_path "$SCROOT_PACKAGE") || scroot_path=
if [ -z "$scroot_path" ]; then
    abort "! Install SCRoot before installing this module"
fi

bridge_path=$(single_package_path "$BRIDGE_PACKAGE") || bridge_path=
bridge_hash=$(sha256sum "$bridge_path" 2>/dev/null | cut -d ' ' -f 1)
if [ "$bridge_hash" != "$EXPECTED_BRIDGE_SHA256" ]; then
    abort "! Install the SCR Overview bridge before this module"
fi

ui_print "- Compatible stock home and verified delta found"
ui_print "- The patched APK will be generated locally on this SCR-01"
