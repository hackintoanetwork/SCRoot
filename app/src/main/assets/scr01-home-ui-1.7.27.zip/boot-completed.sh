#!/system/bin/sh

MODDIR=${0%/*}
LOG_FILE="$MODDIR/service.log"
TARGET_APK=/system/priv-app/MHSHome/MHSHome.apk
PATCHER="$MODDIR/bin/scbspatch"
PATCH_FILE="$MODDIR/patch/MHSHome.bsdiff"
GENERATED_DIR="$MODDIR/generated"
PAYLOAD_APK="$GENERATED_DIR/MHSHome.apk"
HOME_PACKAGE=com.samsung.android.mhshome
HOME_COMPONENT=com.samsung.android.mhshome/.MainActivity
SCROOT_PACKAGE=com.scr01.scroot
BRIDGE_PACKAGE=com.sec.android.app.launcher
NSENTER=/system/bin/nsenter
TIMEOUT=/system/bin/timeout
SYNC=/system/bin/sync
FLOCK=/system/bin/flock
EXPECTED_DEVICE=SCR01
EXPECTED_STOCK_SHA256=d69adf660a95ff156b02ff2f08e52c0c4acf0bdbb5fa8c3b7c5dd48b96138d45
EXPECTED_PATCH_SHA256=bb226a5f4b7b2fe86b6f24870798a25c605fa123b4d578a69db51c4d50adf1bd
EXPECTED_PATCHER_SHA256=50688c893eab8fcf73277590f1b0486f1ba4a63431f568296ddbd864864d3089
EXPECTED_DELTA_SHA256=18fb9cd306d221841c322d29470d4d0a9efd1be984e008e679e4d3868f581cbb
EXPECTED_BRIDGE_SHA256=e21c90ee1c70c0a3134f532e179bef1cdaaa47105f63fbce4ca850596607258d

umask 077
MOUNT_CHANGED=0
ACTIVATION_STARTED=0
ACTIVATION_COMMITTED=0
LOCK_HELD=0
temporary_apk=

log_line() {
    printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG_FILE"
}

cleanup_patch_temporary() {
    [ -n "$temporary_apk" ] || return 0
    case "$temporary_apk" in
        "$GENERATED_DIR"/.MHSHome.apk.*)
            rm -f "$temporary_apk" "$temporary_apk".*.bz2
            cleanup_result=$?
            temporary_apk=
            return "$cleanup_result"
            ;;
        *)
            temporary_apk=
            return 1
            ;;
    esac
}

LOCK_FILE=/data/adb/.scr01_scroot_menu.activation.lock

acquire_activation_lock() {
    [ -x "$FLOCK" ] || return 1
    [ ! -L "$LOCK_FILE" ] || return 1
    [ ! -e "$LOCK_FILE" ] || [ -f "$LOCK_FILE" ] || return 1
    : >> "$LOCK_FILE" || return 1
    chmod 0600 "$LOCK_FILE" || return 1
    exec 0<> "$LOCK_FILE" || return 1
    count=0
    while ! "$FLOCK" -n 0; do
        count=$((count + 1))
        if [ "$count" -ge 1200 ]; then
            exec 0< /dev/null
            return 1
        fi
        sleep 0.1
    done
    LOCK_HELD=1
}

release_activation_lock() {
    if [ "$LOCK_HELD" = 1 ]; then
        "$FLOCK" -u 0 2>/dev/null || true
        exec 0< /dev/null
        LOCK_HELD=0
    fi
}

file_sha256() {
    sha256sum "$1" 2>/dev/null | cut -d ' ' -f 1
}

single_package_path() {
    package_name=$1
    package_paths=$("$TIMEOUT" -k 1s 10s pm path "$package_name" 2>/dev/null) ||
        return 1
    package_path=
    package_count=0
    while IFS= read -r package_line; do
        case "$package_line" in
            package:*)
                package_candidate=${package_line#package:}
                [ -n "$package_candidate" ] || return 1
                package_count=$((package_count + 1))
                [ "$package_count" -eq 1 ] || return 1
                package_path=$package_candidate
                ;;
            "") ;;
            *) return 1 ;;
        esac
    done <<EOF
$package_paths
EOF
    [ "$package_count" -eq 1 ] && [ -n "$package_path" ] || return 1
    printf '%s\n' "$package_path"
}

global_exec() {
    "$NSENTER" -t 1 -m -- "$@"
}

global_file_sha256() {
    global_exec "$TIMEOUT" -k 1s 15s sha256sum "$1" 2>/dev/null |
        cut -d ' ' -f 1
}

is_known_previous_patch() {
    case "$1" in
        524007eeda1460e4df014e377b7e9bb57e6b316a0545fed9ccfc173e3ac0a024|\
        1b6584a705949f592964dc027b2414e7af59ef156748ac93868ad6af5cf9d880|\
        ce7659450509b47458eaaeb0c46dfe3157c6d11cc18f1f2b144c2d16b0d4928e|\
        32cca4a9b41cdbe38bb136decfec6b46b76d6a628613d6a755f0455631eb0d10|\
        ccbf69decb7ffde2bbe768f52aed90945b30069f6a9c952349cded3ed1d26f45|\
        fbea1f8f8bc3d27060baa1fc9aaada8926933cf0f74ff5f147fbb0eba7747c6b|\
        0c9f76b68adde3d14ac54d653b20405e8c71728c247dd6842ad149bea724636a|\
        ab1803ea431d5b1c04241264cb739df9e94da31fe7a5a096a6226158ea0c67f2|\
        ad9ad032d08e5023eb6b51ba71c740e822d0efe83d168e29fb71fec364c71fa8|\
        031554099fd69d95ef5bb3580721bed26e2a4cef06d3a9487006414a2397e4bf|\
        dcf7d3966caf426893270e669b0e9ecf760e8d956b8d9542c263fc341b5636c9|\
        afd5529ec9b469484d56c35ae262d4ecfabfc8f6537fa60fdf109675dc09ea60|\
        abb5ae74eb28fa535e44128df1b66865d4788795cb3ee925c04df0a179c1e912|\
        2fa44dca4260679ebbf1f8e661ed2444d677b232b32c300a83c6ba5e8145488c|\
        8a4362a3012ea44b1a50e3d29b3cebf9f6e16bd2e7b91e20585538219af0283c|\
        77b3c5617775a3df239a2ffdeb2e90282b292b8020d8a6f53216cae200e16c18)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

ensure_generated_apk() {
    generated_hash=$(file_sha256 "$PAYLOAD_APK")
    if [ "$generated_hash" = "$EXPECTED_PATCH_SHA256" ]; then
        log_line "verified locally generated MHSHome payload"
        return 0
    fi

    patcher_hash=$(file_sha256 "$PATCHER")
    delta_hash=$(file_sha256 "$PATCH_FILE")
    if [ "$patcher_hash" != "$EXPECTED_PATCHER_SHA256" ] ||
        [ "$delta_hash" != "$EXPECTED_DELTA_SHA256" ] ||
        [ ! -x /system/bin/bzip2 ] || [ ! -x "$TIMEOUT" ] ||
        [ ! -x "$SYNC" ]; then
        log_line "fail closed: Home patch generator integrity check failed"
        return 1
    fi

    source_hash=$(global_file_sha256 "$TARGET_APK")
    if [ "$source_hash" = "$EXPECTED_STOCK_SHA256" ]; then
        :
    elif [ "$source_hash" = "$EXPECTED_PATCH_SHA256" ] ||
        is_known_previous_patch "$source_hash"; then
        log_line "removing the previous Home bind mount before local generation"
        if ! global_exec "$TIMEOUT" -k 1s 10s \
            umount "$TARGET_APK" >/dev/null 2>&1; then
            log_line "previous Home bind is busy; using lazy detach"
            global_exec "$TIMEOUT" -k 1s 10s umount -l "$TARGET_APK" \
                >> "$LOG_FILE" 2>&1 || return 1
        fi
        MOUNT_CHANGED=1
        source_hash=$(global_file_sha256 "$TARGET_APK")
    else
        log_line "fail closed: unsupported Home source hash ($source_hash)"
        return 1
    fi
    if [ "$source_hash" != "$EXPECTED_STOCK_SHA256" ]; then
        log_line "fail closed: exact stock Home was not exposed ($source_hash)"
        return 1
    fi

    mkdir -p "$GENERATED_DIR" || return 1
    chmod 0700 "$GENERATED_DIR" || return 1
    rm -f "$GENERATED_DIR"/.MHSHome.apk.*
    temporary_apk="$GENERATED_DIR/.MHSHome.apk.$$"
    rm -f "$temporary_apk" "$temporary_apk".*.bz2
    log_line "generating MHSHome from verified stock APK"
    if ! global_exec "$TIMEOUT" -k 2s 60s \
        "$PATCHER" "$TARGET_APK" "$temporary_apk" "$PATCH_FILE" \
        >> "$LOG_FILE" 2>&1; then
        cleanup_patch_temporary
        log_line "fail closed: local Home patch generation failed"
        return 1
    fi
    generated_hash=$(file_sha256 "$temporary_apk")
    if [ "$generated_hash" != "$EXPECTED_PATCH_SHA256" ]; then
        cleanup_patch_temporary
        log_line "fail closed: generated Home hash mismatch ($generated_hash)"
        return 1
    fi
    chmod 0644 "$temporary_apk" || {
        cleanup_patch_temporary
        return 1
    }
    mv -f "$temporary_apk" "$PAYLOAD_APK" || {
        cleanup_patch_temporary
        return 1
    }
    temporary_apk=
    "$TIMEOUT" -k 2s 20s "$SYNC" || return 1
    generated_hash=$(file_sha256 "$PAYLOAD_APK")
    [ "$generated_hash" = "$EXPECTED_PATCH_SHA256" ] || return 1
    log_line "local MHSHome generation complete"
}

start_stock_home() {
    if ! "$TIMEOUT" -k 1s 8s am force-stop "$HOME_PACKAGE" \
        >> "$LOG_FILE" 2>&1; then
        log_line "watchdog: MHSHome stop failed or timed out"
        return 1
    fi
    if ! "$TIMEOUT" -k 1s 12s am start \
        -a android.intent.action.MAIN -c android.intent.category.HOME \
        -n "$HOME_COMPONENT" >> "$LOG_FILE" 2>&1; then
        log_line "watchdog: MHSHome start failed or timed out"
        return 1
    fi
}

wait_for_stock_home() {
    count=0
    while [ "$count" -lt 50 ]; do
        home_pid=$(pidof "$HOME_PACKAGE" 2>/dev/null | cut -d ' ' -f 1)
        if [ -n "$home_pid" ]; then
            printf '%s\n' "$home_pid"
            return 0
        fi
        sleep 0.2
        count=$((count + 1))
    done
    return 1
}

home_process_ready() {
    expected_pid=$1
    case "$expected_pid" in
        ''|*[!0-9]*) return 1 ;;
    esac
    [ "$(pidof "$HOME_PACKAGE" 2>/dev/null)" = "$expected_pid" ] || return 1
    [ -r "/proc/$expected_pid/cmdline" ] || return 1
    cmdline_name=$({
        tr '\000' '\n' < "/proc/$expected_pid/cmdline"
    } 2>/dev/null | sed -n '1p')
    [ "$cmdline_name" = "$HOME_PACKAGE" ] || return 1
    process_state_file="$MODDIR/.home-process-state.$$"
    rm -f "$process_state_file"
    if ! "$TIMEOUT" -k 1s 10s dumpsys activity processes "$HOME_PACKAGE" \
        > "$process_state_file" 2>/dev/null; then
        rm -f "$process_state_file"
        return 1
    fi
    grep -q " $expected_pid:$HOME_PACKAGE/" "$process_state_file" &&
        grep -q "mHomeProcess: ProcessRecord{.* $expected_pid:$HOME_PACKAGE/" \
            "$process_state_file" &&
        grep -q 'thread=android.app.IApplicationThread' "$process_state_file" &&
        ! grep -q 'crashing=true' "$process_state_file"
    process_state_rc=$?
    rm -f "$process_state_file"
    return "$process_state_rc"
}

restore_stock_home() {
    log_line "watchdog: restoring stock MHSHome"
    "$TIMEOUT" -k 1s 8s am force-stop "$HOME_PACKAGE" \
        >> "$LOG_FILE" 2>&1 || log_line "watchdog: stock Home force-stop failed"
    global_exec "$TIMEOUT" -k 1s 10s umount "$TARGET_APK" \
        >> "$LOG_FILE" 2>&1 ||
        global_exec "$TIMEOUT" -k 1s 10s umount -l "$TARGET_APK" \
            >> "$LOG_FILE" 2>&1 || true
    restored_hash=$(global_file_sha256 "$TARGET_APK")
    if [ "$restored_hash" != "$EXPECTED_STOCK_SHA256" ]; then
        log_line "watchdog: stock Home hash was not restored ($restored_hash)"
        return 1
    fi
    if ! start_stock_home; then
        log_line "watchdog: stock Home restart failed"
        return 1
    fi
    MOUNT_CHANGED=0
    ACTIVATION_STARTED=0
    return 0
}

handle_activation_signal() {
    trap - HUP INT TERM
    log_line "interrupted: cleaning incomplete Home activation"
    exit 99
}

cleanup_on_exit() {
    cleanup_rc=$?
    trap - EXIT HUP INT TERM
    cleanup_patch_temporary || log_line "watchdog: Home patch temporary cleanup failed"
    if { [ "$ACTIVATION_STARTED" = 1 ] || [ "$MOUNT_CHANGED" = 1 ]; } &&
        [ "$ACTIVATION_COMMITTED" != 1 ]; then
        restore_stock_home || log_line "watchdog: Home rollback could not be verified"
    fi
    rm -f "$MODDIR"/.home-process-state.$$
    release_activation_lock
    exit "$cleanup_rc"
}

if ! acquire_activation_lock; then
    exit 90
fi
trap cleanup_on_exit EXIT
trap handle_activation_signal HUP INT TERM

: > "$LOG_FILE"
log_line "boot-completed start"

if [ "$(getprop sys.boot_completed)" != "1" ]; then
    log_line "fail closed: boot completion property is not set"
    exit 10
fi

sleep 5

if [ ! -x "$NSENTER" ] || ! global_exec true >/dev/null 2>&1; then
    log_line "fail closed: init mount namespace is unavailable"
    exit 11
fi

if [ ! -x "$TIMEOUT" ] || [ ! -x "$SYNC" ]; then
    log_line "fail closed: required activation runtime is unavailable"
    exit 23
fi

if [ "$(getprop ro.product.device)" != "$EXPECTED_DEVICE" ]; then
    log_line "fail closed: unsupported device $(getprop ro.product.device)"
    exit 12
fi

if ! global_exec "$TIMEOUT" -k 1s 10s test -f "$TARGET_APK" ||
    [ ! -f "$PATCHER" ] || [ ! -f "$PATCH_FILE" ]; then
    log_line "fail closed: stock APK or local patch artifacts missing"
    exit 13
fi

if ! ensure_generated_apk; then
    log_line "fail closed: verified Home payload could not be generated"
    exit 13
fi

payload_hash=$(file_sha256 "$PAYLOAD_APK")
if [ "$payload_hash" != "$EXPECTED_PATCH_SHA256" ]; then
    log_line "fail closed: payload hash mismatch ($payload_hash)"
    exit 14
fi

scroot_path=$(single_package_path "$SCROOT_PACKAGE") || scroot_path=
if [ -z "$scroot_path" ]; then
    log_line "fail closed: SCRoot is not installed"
    exit 15
fi

bridge_path=$(single_package_path "$BRIDGE_PACKAGE") || bridge_path=
bridge_hash=$(file_sha256 "$bridge_path")
if [ "$bridge_hash" != "$EXPECTED_BRIDGE_SHA256" ]; then
    log_line "fail closed: SCR Overview bridge is missing or untrusted"
    exit 16
fi

stock_hash=$(global_file_sha256 "$TARGET_APK")
if [ "$stock_hash" = "$EXPECTED_PATCH_SHA256" ]; then
    log_line "patched MHSHome is already mounted in init namespace"
elif is_known_previous_patch "$stock_hash"; then
    log_line "previous SCRoot MHSHome patch detected; replacing its bind mount"
    global_exec "$TIMEOUT" -k 1s 10s umount "$TARGET_APK" \
        >> "$LOG_FILE" 2>&1 ||
        global_exec "$TIMEOUT" -k 1s 10s umount -l "$TARGET_APK" \
            >> "$LOG_FILE" 2>&1 || exit 17
    MOUNT_CHANGED=1
    stock_hash=$(global_file_sha256 "$TARGET_APK")
    if [ "$stock_hash" != "$EXPECTED_STOCK_SHA256" ]; then
        log_line "fail closed: stock MHSHome was not restored ($stock_hash)"
        restore_stock_home
        exit 18
    fi
    if ! global_exec "$TIMEOUT" -k 1s 10s \
        mount --bind "$PAYLOAD_APK" "$TARGET_APK" >> "$LOG_FILE" 2>&1; then
        log_line "fail closed: init-namespace replacement bind mount failed"
        restore_stock_home
        exit 17
    fi
elif [ "$stock_hash" = "$EXPECTED_STOCK_SHA256" ]; then
    if ! global_exec "$TIMEOUT" -k 1s 10s \
        mount --bind "$PAYLOAD_APK" "$TARGET_APK" >> "$LOG_FILE" 2>&1; then
        log_line "fail closed: init-namespace bind mount failed"
        exit 17
    fi
    MOUNT_CHANGED=1
else
    log_line "fail closed: unsupported stock MHSHome hash ($stock_hash)"
    exit 18
fi

mounted_hash=$(global_file_sha256 "$TARGET_APK")
if [ "$mounted_hash" != "$EXPECTED_PATCH_SHA256" ]; then
    log_line "watchdog: mounted APK hash mismatch ($mounted_hash)"
    restore_stock_home
    exit 19
fi

ACTIVATION_STARTED=1
if ! start_stock_home; then
    log_line "watchdog: patched MHSHome launch command failed"
    restore_stock_home
    exit 20
fi

home_pid=$(wait_for_stock_home)
if [ -z "$home_pid" ]; then
    log_line "watchdog: patched MHSHome did not stay alive"
    restore_stock_home
    exit 20
fi

sleep 8

if ! home_process_ready "$home_pid"; then
    log_line "watchdog: patched MHSHome restarted during first stability window"
    restore_stock_home
    exit 21
fi

sleep 10

if ! home_process_ready "$home_pid"; then
    log_line "watchdog: patched MHSHome restarted during second stability window"
    restore_stock_home
    exit 22
fi

log_line "success: SCRoot menu and swipe-up Apps gesture active in init namespace"
ACTIVATION_COMMITTED=1
exit 0
