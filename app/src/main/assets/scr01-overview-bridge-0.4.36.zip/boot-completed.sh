#!/system/bin/sh

MODDIR=${0%/*}
LOG_FILE="$MODDIR/service.log"
TARGET_APK=/system/system_ext/priv-app/SystemUI/SystemUI.apk
PATCHER="$MODDIR/bin/scbspatch"
PATCH_FILE="$MODDIR/patch/SystemUI.bsdiff"
GENERATED_DIR="$MODDIR/generated"
PAYLOAD_APK="$GENERATED_DIR/SystemUI.apk"
SYSTEMUI_PACKAGE=com.android.systemui
BRIDGE_PACKAGE=com.sec.android.app.launcher
BRIDGE_COMPONENT=com.sec.android.app.launcher/com.scr01.overview.TouchInteractionService
QUICKSTEP_ACTION=android.intent.action.QUICKSTEP_SERVICE
NSENTER=/system/bin/nsenter
APP_PROCESS=/system/bin/app_process
TIMEOUT=/system/bin/timeout
SYNC=/system/bin/sync
FLOCK=/system/bin/flock
TASK_BRIDGE_NAME=scr01-task-bridge
TASK_BRIDGE_PID_FILE="$MODDIR/task-bridge.pid"
TASK_BRIDGE_READY_FILE="$MODDIR/task-bridge.ready"
TASK_BRIDGE_LOG="$MODDIR/task-bridge.log"
EXPECTED_DEVICE=SCR01
EXPECTED_STOCK_SHA256=83d1cf22a48b864351c4e3fde0f6463f54806819d12b5abd5596275f7e2b6f20
EXPECTED_PREVIOUS_PATCH_SHA256=8705b9e5494447ee062152c582c801e0b8b6f1f2bdba538bb75d58f94cc0f1d1
EXPECTED_PATCH_SHA256=6814f34f7a382ed197b647294ccd166d78556431ec1cb3d914e2736837c6db14
EXPECTED_BRIDGE_SHA256=e21c90ee1c70c0a3134f532e179bef1cdaaa47105f63fbce4ca850596607258d
EXPECTED_PATCHER_SHA256=50688c893eab8fcf73277590f1b0486f1ba4a63431f568296ddbd864864d3089
EXPECTED_DELTA_SHA256=9d7a2260854ca8f5562e15392a1c3c6939775e8a9c5b2aab6409cb1b6799a5f3

umask 077
ACTIVATION_STARTED=0
MOUNT_CHANGED=0
ACTIVATION_COMMITTED=0
ACTIVE_REUSE_STARTED=0
TASK_BRIDGE_STARTED=0
LOCK_HELD=0
temporary_apk=

log_line() {
    printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG_FILE"
}

cleanup_patch_temporary() {
    [ -n "$temporary_apk" ] || return 0
    case "$temporary_apk" in
        "$GENERATED_DIR"/.SystemUI.apk.*)
            rm -f "$temporary_apk" "$temporary_apk".*.bz2
            cleanup_result=$?
            temporary_apk=
            return "$cleanup_result"
            ;;
        *)
            temporary_apk=
            return 1
            ;;
    esac
}

LOCK_FILE=/data/adb/.scr01_overview_bridge.activation.lock

acquire_activation_lock() {
    [ -x "$FLOCK" ] || return 1
    [ ! -L "$LOCK_FILE" ] || return 1
    [ ! -e "$LOCK_FILE" ] || [ -f "$LOCK_FILE" ] || return 1
    : >> "$LOCK_FILE" || return 1
    chmod 0600 "$LOCK_FILE" || return 1
    exec 0<> "$LOCK_FILE" || return 1
    count=0
    while ! "$FLOCK" -n 0; do
        count=$((count + 1))
        if [ "$count" -ge 1200 ]; then
            exec 0< /dev/null
            return 1
        fi
        sleep 0.1
    done
    LOCK_HELD=1
}

release_activation_lock() {
    if [ "$LOCK_HELD" = 1 ]; then
        "$FLOCK" -u 0 2>/dev/null || true
        exec 0< /dev/null
        LOCK_HELD=0
    fi
}

file_sha256() {
    sha256sum "$1" 2>/dev/null | cut -d ' ' -f 1
}

single_package_path() {
    package_name=$1
    package_paths=$("$TIMEOUT" -k 1s 10s pm path "$package_name" 2>/dev/null) ||
        return 1
    package_path=
    package_count=0
    while IFS= read -r package_line; do
        case "$package_line" in
            package:*)
                package_candidate=${package_line#package:}
                [ -n "$package_candidate" ] || return 1
                package_count=$((package_count + 1))
                [ "$package_count" -eq 1 ] || return 1
                package_path=$package_candidate
                ;;
            "") ;;
            *) return 1 ;;
        esac
    done <<EOF
$package_paths
EOF
    [ "$package_count" -eq 1 ] && [ -n "$package_path" ] || return 1
    printf '%s\n' "$package_path"
}

single_quickstep_component() {
    quickstep_components=$(
        "$TIMEOUT" -k 1s 10s cmd package \
            query-services --brief --components --query-flags 0 \
            -a "$QUICKSTEP_ACTION" 2>/dev/null
    ) || return 1
    quickstep_component=
    quickstep_count=0
    while IFS= read -r quickstep_line; do
        case "$quickstep_line" in
            "") ;;
            */*)
                quickstep_count=$((quickstep_count + 1))
                [ "$quickstep_count" -eq 1 ] || return 1
                quickstep_component=$quickstep_line
                ;;
            *) return 1 ;;
        esac
    done <<EOF
$quickstep_components
EOF
    [ "$quickstep_count" -eq 1 ] && [ -n "$quickstep_component" ] || return 1
    printf '%s\n' "$quickstep_component"
}

global_exec() {
    "$NSENTER" -t 1 -m -- "$@"
}

global_file_sha256() {
    global_exec "$TIMEOUT" -k 1s 15s sha256sum "$1" 2>/dev/null |
        cut -d ' ' -f 1
}

ensure_generated_apk() {
    generated_hash=$(file_sha256 "$PAYLOAD_APK")
    if [ "$generated_hash" = "$EXPECTED_PATCH_SHA256" ]; then
        log_line "verified locally generated SystemUI payload"
        return 0
    fi

    patcher_hash=$(file_sha256 "$PATCHER")
    delta_hash=$(file_sha256 "$PATCH_FILE")
    if [ "$patcher_hash" != "$EXPECTED_PATCHER_SHA256" ] ||
        [ "$delta_hash" != "$EXPECTED_DELTA_SHA256" ] ||
        [ ! -x /system/bin/bzip2 ] || [ ! -x "$TIMEOUT" ] ||
        [ ! -x "$SYNC" ]; then
        log_line "fail closed: SystemUI patch generator integrity check failed"
        return 1
    fi

    source_hash=$(global_file_sha256 "$TARGET_APK")
    case "$source_hash" in
        "$EXPECTED_STOCK_SHA256")
            ;;
        "$EXPECTED_PATCH_SHA256"|"$EXPECTED_PREVIOUS_PATCH_SHA256")
            log_line "removing the previous SystemUI bind mount before local generation"
            if ! global_exec "$TIMEOUT" -k 1s 10s \
                umount "$TARGET_APK" >/dev/null 2>&1; then
                log_line "previous SystemUI bind is busy; using lazy detach"
                global_exec "$TIMEOUT" -k 1s 10s umount -l "$TARGET_APK" \
                    >> "$LOG_FILE" 2>&1 || return 1
            fi
            MOUNT_CHANGED=1
            source_hash=$(global_file_sha256 "$TARGET_APK")
            ;;
        *)
            log_line "fail closed: unsupported SystemUI source hash ($source_hash)"
            return 1
            ;;
    esac
    if [ "$source_hash" != "$EXPECTED_STOCK_SHA256" ]; then
        log_line "fail closed: exact stock SystemUI was not exposed ($source_hash)"
        return 1
    fi

    mkdir -p "$GENERATED_DIR" || return 1
    chmod 0700 "$GENERATED_DIR" || return 1
    rm -f "$GENERATED_DIR"/.SystemUI.apk.*
    temporary_apk="$GENERATED_DIR/.SystemUI.apk.$$"
    rm -f "$temporary_apk" "$temporary_apk".*.bz2
    log_line "generating SystemUI from verified stock APK"
    if ! global_exec "$TIMEOUT" -k 2s 60s \
        "$PATCHER" "$TARGET_APK" "$temporary_apk" "$PATCH_FILE" \
        >> "$LOG_FILE" 2>&1; then
        cleanup_patch_temporary
        log_line "fail closed: local SystemUI patch generation failed"
        return 1
    fi
    generated_hash=$(file_sha256 "$temporary_apk")
    if [ "$generated_hash" != "$EXPECTED_PATCH_SHA256" ]; then
        cleanup_patch_temporary
        log_line "fail closed: generated SystemUI hash mismatch ($generated_hash)"
        return 1
    fi
    chmod 0644 "$temporary_apk" || {
        cleanup_patch_temporary
        return 1
    }
    mv -f "$temporary_apk" "$PAYLOAD_APK" || {
        cleanup_patch_temporary
        return 1
    }
    temporary_apk=
    "$TIMEOUT" -k 2s 20s "$SYNC" || return 1
    generated_hash=$(file_sha256 "$PAYLOAD_APK")
    [ "$generated_hash" = "$EXPECTED_PATCH_SHA256" ] || return 1
    log_line "local SystemUI generation complete"
}

systemui_pid() {
    pidof "$SYSTEMUI_PACKAGE" 2>/dev/null | cut -d ' ' -f 1
}

task_bridge_pid() {
    bridge_pid=$(cat "$TASK_BRIDGE_PID_FILE" 2>/dev/null)
    case "$bridge_pid" in
        ''|*[!0-9]*) return 1 ;;
    esac
    [ -d "/proc/$bridge_pid" ] || return 1
    bridge_name=$({
        tr '\000' '\n' < "/proc/$bridge_pid/cmdline"
    } 2>/dev/null | sed -n '1p')
    [ "$bridge_name" = "$TASK_BRIDGE_NAME" ] || return 1
    printf '%s\n' "$bridge_pid"
}

stop_task_bridge() {
    bridge_pids="$(cat "$TASK_BRIDGE_PID_FILE" 2>/dev/null) $(pidof "$TASK_BRIDGE_NAME" 2>/dev/null)"
    seen_bridge_pids=' '
    for bridge_pid in $bridge_pids; do
        case "$bridge_pid" in
            ''|*[!0-9]*) continue ;;
        esac
        case "$seen_bridge_pids" in
            *" $bridge_pid "*) continue ;;
        esac
        seen_bridge_pids="$seen_bridge_pids$bridge_pid "
        bridge_name=$({
            tr '\000' '\n' < "/proc/$bridge_pid/cmdline"
        } 2>/dev/null | sed -n '1p')
        if [ "$bridge_name" != "$TASK_BRIDGE_NAME" ]; then
            continue
        fi
        kill -TERM "$bridge_pid" 2>/dev/null
        count=0
        while [ "$count" -lt 20 ] && kill -0 "$bridge_pid" 2>/dev/null; do
            sleep 0.1
            count=$((count + 1))
        done
        kill -KILL "$bridge_pid" 2>/dev/null || true
    done
    rm -f "$TASK_BRIDGE_PID_FILE" "$TASK_BRIDGE_READY_FILE"
    TASK_BRIDGE_STARTED=0
}

start_task_bridge() {
    bridge_apk=$1
    stop_task_bridge
    : > "$TASK_BRIDGE_LOG"
    CLASSPATH="$bridge_apk" "$APP_PROCESS" /system/bin \
        --nice-name="$TASK_BRIDGE_NAME" \
        com.android.quickstep.RootTaskBridgeServer "$MODDIR" "$bridge_apk" \
        </dev/null >> "$TASK_BRIDGE_LOG" 2>&1 &
    bridge_pid=$!
    printf '%s\n' "$bridge_pid" > "$TASK_BRIDGE_PID_FILE"
    TASK_BRIDGE_STARTED=1
    chmod 0600 "$TASK_BRIDGE_PID_FILE" 2>/dev/null || {
        stop_task_bridge
        return 1
    }
    count=0
    while [ "$count" -lt 60 ]; do
        if ! kill -0 "$bridge_pid" 2>/dev/null; then
            log_line "task broker exited during startup"
            tail -n 12 "$TASK_BRIDGE_LOG" >> "$LOG_FILE" 2>/dev/null
            stop_task_bridge
            return 1
        fi
        if grep -q '^protocol=1 uid=0 tasks=[0-9][0-9]*$' \
            "$TASK_BRIDGE_READY_FILE" 2>/dev/null; then
            chmod 0600 "$TASK_BRIDGE_READY_FILE" 2>/dev/null || {
                stop_task_bridge
                return 1
            }
            return 0
        fi
        sleep 0.1
        count=$((count + 1))
    done
    log_line "task broker readiness timed out"
    tail -n 12 "$TASK_BRIDGE_LOG" >> "$LOG_FILE" 2>/dev/null
    stop_task_bridge
    return 1
}

active_quickstep_ready() {
    active_pid=$(systemui_pid)
    [ -n "$active_pid" ] || return 1
    active_state_file="$MODDIR/.systemui-state.$$"
    rm -f "$active_state_file"
    if ! "$TIMEOUT" -k 1s 10s dumpsys activity \
        service com.android.systemui/.SystemUIService \
        > "$active_state_file" 2>/dev/null; then
        rm -f "$active_state_file"
        return 1
    fi
    grep -q 'quickStepIntentResolved=true' "$active_state_file" &&
        grep -q 'isConnected=true' "$active_state_file" &&
        grep -q 'mCurrentLayout: .*recent' "$active_state_file"
    active_state_rc=$?
    rm -f "$active_state_file"
    return "$active_state_rc"
}

reuse_active_systemui() {
    active_bridge_apk=$1
    [ "$(global_file_sha256 "$TARGET_APK")" = "$EXPECTED_PATCH_SHA256" ] ||
        return 1
    ACTIVE_REUSE_STARTED=1
    if ! start_task_bridge "$active_bridge_apk"; then
        ACTIVE_REUSE_STARTED=0
        return 1
    fi
    active_component=$(single_quickstep_component) || active_component=
    if [ "$active_component" = "$BRIDGE_COMPONENT" ] &&
        active_quickstep_ready; then
        log_line "existing patched SystemUI and Quickstep connection reused without restart"
        ACTIVATION_COMMITTED=1
        ACTIVE_REUSE_STARTED=0
        return 0
    fi
    stop_task_bridge
    ACTIVE_REUSE_STARTED=0
    return 1
}

wait_for_new_systemui() {
    previous_pid=$1
    count=0
    while [ "$count" -lt 20 ]; do
        current_pid=$(systemui_pid)
        if [ -n "$current_pid" ] && [ "$current_pid" != "$previous_pid" ]; then
            printf '%s\n' "$current_pid"
            return 0
        fi
        sleep 1
        count=$((count + 1))
    done
    return 1
}

restart_systemui() {
    old_pid=$(systemui_pid)
    if [ -n "$old_pid" ]; then
        kill -TERM "$old_pid" >> "$LOG_FILE" 2>&1
    fi
    wait_for_new_systemui "$old_pid"
}

restore_stock_systemui() {
    log_line "watchdog: restoring stock SystemUI"
    stop_task_bridge
    global_exec "$TIMEOUT" -k 1s 10s umount "$TARGET_APK" \
        >> "$LOG_FILE" 2>&1 ||
        global_exec "$TIMEOUT" -k 1s 10s umount -l "$TARGET_APK" \
            >> "$LOG_FILE" 2>&1 || true
    restored_hash=$(global_file_sha256 "$TARGET_APK")
    if [ "$restored_hash" != "$EXPECTED_STOCK_SHA256" ]; then
        log_line "watchdog: stock SystemUI hash was not restored ($restored_hash)"
        return 1
    fi
    restored_pid=$(restart_systemui)
    if [ -z "$restored_pid" ]; then
        log_line "watchdog: stock SystemUI restart failed"
        return 1
    fi
    MOUNT_CHANGED=0
    ACTIVATION_STARTED=0
    ACTIVE_REUSE_STARTED=0
    return 0
}

handle_activation_signal() {
    trap - HUP INT TERM
    log_line "interrupted: cleaning incomplete SystemUI activation"
    exit 99
}

cleanup_on_exit() {
    cleanup_rc=$?
    trap - EXIT HUP INT TERM
    cleanup_patch_temporary || log_line "watchdog: SystemUI patch temporary cleanup failed"
    if [ "$ACTIVE_REUSE_STARTED" = 1 ] &&
        [ "$ACTIVATION_COMMITTED" != 1 ]; then
        if [ -n "$bridge_path" ] &&
            start_task_bridge "$bridge_path" &&
            [ "$(global_file_sha256 "$TARGET_APK")" = "$EXPECTED_PATCH_SHA256" ] &&
            active_quickstep_ready; then
            log_line "watchdog: task broker restored after interrupted active reuse"
            ACTIVE_REUSE_STARTED=0
            ACTIVATION_STARTED=0
        else
            restore_stock_systemui ||
                log_line "watchdog: SystemUI rollback could not be verified"
        fi
    elif { [ "$ACTIVATION_STARTED" = 1 ] || [ "$MOUNT_CHANGED" = 1 ]; } &&
        [ "$ACTIVATION_COMMITTED" != 1 ]; then
        restore_stock_systemui ||
            log_line "watchdog: SystemUI rollback could not be verified"
    elif [ "$TASK_BRIDGE_STARTED" = 1 ] &&
        [ "$ACTIVATION_COMMITTED" != 1 ]; then
        stop_task_bridge
    fi
    rm -f "$MODDIR"/.systemui-state.$$ "$MODDIR"/.recents-state.$$
    release_activation_lock
    exit "$cleanup_rc"
}

if ! acquire_activation_lock; then
    exit 90
fi
trap cleanup_on_exit EXIT
trap handle_activation_signal HUP INT TERM

: > "$LOG_FILE"
log_line "boot-completed start"

if [ "$(getprop sys.boot_completed)" != "1" ]; then
    log_line "fail closed: boot completion property is not set"
    exit 10
fi

sleep 8

if [ ! -x "$TIMEOUT" ] || [ ! -x "$SYNC" ]; then
    log_line "fail closed: required activation runtime is unavailable"
    exit 25
fi

if [ ! -x "$NSENTER" ] || ! global_exec true >/dev/null 2>&1; then
    log_line "fail closed: init mount namespace is unavailable"
    exit 11
fi

if [ "$(getprop ro.product.device)" != "$EXPECTED_DEVICE" ]; then
    log_line "fail closed: unsupported device $(getprop ro.product.device)"
    exit 12
fi

if ! global_exec "$TIMEOUT" -k 1s 10s test -f "$TARGET_APK" ||
    [ ! -f "$PATCHER" ] || [ ! -f "$PATCH_FILE" ]; then
    log_line "fail closed: stock SystemUI or local patch artifacts missing"
    exit 13
fi

bridge_path=$(single_package_path "$BRIDGE_PACKAGE") || bridge_path=
bridge_hash=$(file_sha256 "$bridge_path")
if [ "$bridge_hash" != "$EXPECTED_BRIDGE_SHA256" ]; then
    log_line "fail closed: SCR Overview missing or hash mismatch ($bridge_hash)"
    exit 15
fi

if [ ! -x "$APP_PROCESS" ]; then
    log_line "fail closed: required activation runtime is unavailable"
    exit 25
fi

if reuse_active_systemui "$bridge_path"; then
    exit 0
fi

if ! ensure_generated_apk; then
    log_line "fail closed: verified SystemUI payload could not be generated"
    exit 13
fi

payload_hash=$(file_sha256 "$PAYLOAD_APK")
if [ "$payload_hash" != "$EXPECTED_PATCH_SHA256" ]; then
    log_line "fail closed: SystemUI payload hash mismatch ($payload_hash)"
    exit 14
fi

if ! start_task_bridge "$bridge_path"; then
    log_line "fail closed: authenticated recent-task broker did not start"
    exit 26
fi
broker_state=$(cat "$TASK_BRIDGE_READY_FILE" 2>/dev/null)
log_line "recent-task broker ready ($broker_state)"

resolved_component=$(single_quickstep_component) || resolved_component=
if [ "$resolved_component" != "$BRIDGE_COMPONENT" ]; then
    log_line "fail closed: unexpected Quickstep service ($resolved_component)"
    stop_task_bridge
    exit 16
fi

stock_hash=$(global_file_sha256 "$TARGET_APK")
if [ "$stock_hash" = "$EXPECTED_PATCH_SHA256" ]; then
    log_line "patched SystemUI is already mounted in init namespace"
elif [ "$stock_hash" = "$EXPECTED_STOCK_SHA256" ]; then
    if ! global_exec "$TIMEOUT" -k 1s 10s \
        mount --bind "$PAYLOAD_APK" "$TARGET_APK" >> "$LOG_FILE" 2>&1; then
        log_line "fail closed: init-namespace bind mount failed"
        stop_task_bridge
        exit 17
    fi
    MOUNT_CHANGED=1
else
    log_line "fail closed: unsupported stock SystemUI hash ($stock_hash)"
    stop_task_bridge
    exit 18
fi

mounted_hash=$(global_file_sha256 "$TARGET_APK")
if [ "$mounted_hash" != "$EXPECTED_PATCH_SHA256" ]; then
    log_line "watchdog: mounted SystemUI hash mismatch ($mounted_hash)"
    restore_stock_systemui
    exit 19
fi

ACTIVATION_STARTED=1
new_pid=$(restart_systemui)
if [ -z "$new_pid" ]; then
    log_line "watchdog: SystemUI did not restart"
    restore_stock_systemui
    exit 20
fi

sleep 6

OVERVIEW_STATE_FILE="$MODDIR/.systemui-state.$$"
rm -f "$OVERVIEW_STATE_FILE"
if ! "$TIMEOUT" -k 1s 10s dumpsys activity \
    service com.android.systemui/.SystemUIService \
    > "$OVERVIEW_STATE_FILE" 2>/dev/null; then
    log_line "watchdog: SystemUI service state could not be read"
    rm -f "$OVERVIEW_STATE_FILE"
    restore_stock_systemui
    exit 21
fi
if ! grep -q 'quickStepIntentResolved=true' "$OVERVIEW_STATE_FILE"; then
    log_line "watchdog: Quickstep intent was not resolved"
    rm -f "$OVERVIEW_STATE_FILE"
    restore_stock_systemui
    exit 21
fi
if ! grep -q 'isConnected=true' "$OVERVIEW_STATE_FILE"; then
    log_line "watchdog: SystemUI did not bind SCR Overview"
    rm -f "$OVERVIEW_STATE_FILE"
    restore_stock_systemui
    exit 22
fi
if ! grep -q 'mCurrentLayout: .*recent' "$OVERVIEW_STATE_FILE"; then
    log_line "watchdog: Recents button is missing from the active navigation layout"
    rm -f "$OVERVIEW_STATE_FILE"
    restore_stock_systemui
    exit 23
fi
rm -f "$OVERVIEW_STATE_FILE"

sleep 8

if [ "$(systemui_pid)" != "$new_pid" ]; then
    log_line "watchdog: patched SystemUI restarted during stability window"
    restore_stock_systemui
    exit 24
fi

recents_state_file="$MODDIR/.recents-state.$$"
if "$TIMEOUT" -k 1s 10s dumpsys activity recents \
    > "$recents_state_file" 2>/dev/null &&
    grep -q 'mRecentsUid=-1' "$recents_state_file"; then
    log_line "framework Recents role is pending next-boot system-app scan; root broker active"
elif grep -q 'mRecentsComponent=ComponentInfo{com.sec.android.app.launcher/com.android.quickstep.RecentsActivity}' \
    "$recents_state_file" 2>/dev/null; then
    log_line "framework Recents role registered"
else
    log_line "framework Recents role state unavailable; root broker active"
fi
rm -f "$recents_state_file"

log_line "success: native Recents, task broker and Apps bridge connected (pid=$new_pid)"
ACTIVATION_COMMITTED=1
exit 0
