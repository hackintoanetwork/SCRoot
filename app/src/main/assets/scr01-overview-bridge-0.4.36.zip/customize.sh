#!/system/bin/sh

EXPECTED_DEVICE=SCR01
TARGET_APK=/system/system_ext/priv-app/SystemUI/SystemUI.apk
PATCHER="$MODPATH/bin/scbspatch"
PATCH_FILE="$MODPATH/patch/SystemUI.bsdiff"
BRIDGE_PACKAGE=com.sec.android.app.launcher
BRIDGE_APK="$MODPATH/app/SCROverview.apk"
TIMEOUT=/system/bin/timeout
EXPECTED_STOCK_SHA256=83d1cf22a48b864351c4e3fde0f6463f54806819d12b5abd5596275f7e2b6f20
EXPECTED_PREVIOUS_PATCH_SHA256=8705b9e5494447ee062152c582c801e0b8b6f1f2bdba538bb75d58f94cc0f1d1
EXPECTED_PATCH_SHA256=6814f34f7a382ed197b647294ccd166d78556431ec1cb3d914e2736837c6db14
EXPECTED_PATCHER_SHA256=50688c893eab8fcf73277590f1b0486f1ba4a63431f568296ddbd864864d3089
EXPECTED_DELTA_SHA256=9d7a2260854ca8f5562e15392a1c3c6939775e8a9c5b2aab6409cb1b6799a5f3
EXPECTED_BRIDGE_010_SHA256=78f0bed9ab3466ce4b54aecaabbdcfde46a94d3efcb7670072810ec1e44c714d
EXPECTED_BRIDGE_011_SHA256=fe6741e1162377714879440ff142e3e69a56460afb272b5e4f36dc655b66514f
EXPECTED_BRIDGE_012_SHA256=3599eda02aae3efb6792143cef8c5798d860d01d0c0efb673c0e6a76f47911a1
EXPECTED_BRIDGE_020_SHA256=ad1e9a091991863b8a93c0aec4a77ec15587ac35072fa479fefd20c31ae672fb
EXPECTED_BRIDGE_021_SHA256=8b23124721387e55c14bb19865cb1a827d8d904473b33aa9b3deacd43985f842
EXPECTED_BRIDGE_022_SHA256=92606d70e44cc07b75a6a34f0df4af3b3581597b081e78ead3557bb3fd9ee33d
EXPECTED_BRIDGE_023_SHA256=509359d21f832ccfe3768e2d3655a3fb70d54d4b59755c47a44e149e2f84f4e9
EXPECTED_BRIDGE_024_SHA256=fd01e4b7304c57a5647ade6137895ecc1e22ae20bffa4f39f21cc4f4c1ad173e
EXPECTED_BRIDGE_025_SHA256=fa809a53586452616a2a92c14538190c2ef50029d511738d77b2962b3fd62f45
EXPECTED_BRIDGE_026_SHA256=4bce064cdb3ab6efb4e0dc9156deb3b0e3cbc0a27440859e549c649ecafbd9f6
EXPECTED_BRIDGE_027_SHA256=875c0d845f82f24901263446681dbbbaba3356664c3ebd653f8058afff72fd5f
EXPECTED_BRIDGE_028_SHA256=8d73f01acc05622e9f902426d6f0f2246193292ef758daa70ac3e5df361e9aa4
EXPECTED_BRIDGE_030_SHA256=9badc2aad69446f475f51927502840544564b1656dcc8deaa413babc6d49c9e4
EXPECTED_BRIDGE_031_RC_SHA256=7f951e47fea76c31e480202285db9fa67e3ba83cf1db9f30fe91f64f31b22281
EXPECTED_BRIDGE_031_SHA256=0719ee7206048ba9842bb7dd4ff10e1da06bd6dd19208e8478514602a5131148
EXPECTED_BRIDGE_032_SHA256=8af424399bf9ba19a7a6413b3df4a9a6ca2150ef2ba310854b816a06d7f85515
EXPECTED_BRIDGE_033_SHA256=eb9a407cdd3343230da973f2173b9f858a94f6b2e082c5566e4a9b223f7186a2
EXPECTED_BRIDGE_034_SHA256=df3a3667e30cbf3fc39908297a8f756e25694e96ad1aa56b9a6e89f3d2556151
EXPECTED_BRIDGE_035_SHA256=25f6b7ce497dc372e43d80de3a10f0696030bc3e91f6b3d33e04cd691880de31
EXPECTED_BRIDGE_036_RC_SHA256=92ce96825153445a42aa7597926557156e01daa247faa3f07828a8f3c8a3397b
EXPECTED_BRIDGE_036_SHA256=3122adfecb7f713922dc9160a670b3cb1e814cc2051802c6ca9d98072382ddfd
EXPECTED_BRIDGE_037_SHA256=a54a6fb4e9dd789135373ec2b7e9a2259b328eca7fd7c4703126d76fcf5a4d4b
EXPECTED_BRIDGE_038_SHA256=cf3abca7e370fba9635738c42e4d0a8ea67675486aa948f7b1d2117a56c536fd
EXPECTED_BRIDGE_039_SHA256=9440664852cde03fadae35a1b2076cb59489bf557dcd91718c1f5913f22f832c
EXPECTED_BRIDGE_040_SHA256=e3f4c16f9f0ca502a0dc0ba738f553a7a7f02b675c9dcd4ed91cc3b9772cd552
EXPECTED_BRIDGE_041_SHA256=989017ec4a7bd65b6144931d1da17c08bdb950a291397f7bed9438e207ddbdd4
EXPECTED_BRIDGE_042_SHA256=a51929e36c79a39aba9974772a064d5a3f3ae8738c2231e13f21e1f5cebe2e0c
EXPECTED_BRIDGE_043_SHA256=8b7546c4d18e5068429d184fdc91bb662c1e9cbb0c6b41ef7d23b11d7c0d3e27
EXPECTED_BRIDGE_044_SHA256=3cf8c51f9a9152e01f119afed41006123e0cd659fe087ba874c50209557b3743
EXPECTED_BRIDGE_045_SHA256=4ee9190fb610fc32978dab0433604338bd46f132a6e653f3196ba2d44f9e9db2
EXPECTED_BRIDGE_046_SHA256=022c46ac3094848da36022994bc1dfedb991f34a0db84a6595c8dfeb5fe25496
EXPECTED_BRIDGE_SHA256=e21c90ee1c70c0a3134f532e179bef1cdaaa47105f63fbce4ca850596607258d

ui_print "- Checking SCR-01 SystemUI compatibility"

if [ ! -x "$TIMEOUT" ]; then
    abort "! Required timeout runtime is unavailable"
fi

device_name=$(getprop ro.product.device)
if [ "$device_name" != "$EXPECTED_DEVICE" ]; then
    abort "! Unsupported device: $device_name"
fi

if [ ! -f "$TARGET_APK" ]; then
    abort "! Stock SystemUI APK is missing"
fi

systemui_hash=$(sha256sum "$TARGET_APK" 2>/dev/null | cut -d ' ' -f 1)
case "$systemui_hash" in
    "$EXPECTED_STOCK_SHA256"|"$EXPECTED_PREVIOUS_PATCH_SHA256"|"$EXPECTED_PATCH_SHA256")
        ;;
    *)
        abort "! Unsupported SystemUI build: $systemui_hash"
        ;;
esac

if [ ! -f "$PATCHER" ] || [ ! -f "$PATCH_FILE" ]; then
    abort "! On-device SystemUI patch generator is missing"
fi

patcher_hash=$(sha256sum "$PATCHER" 2>/dev/null | cut -d ' ' -f 1)
delta_hash=$(sha256sum "$PATCH_FILE" 2>/dev/null | cut -d ' ' -f 1)
if [ "$patcher_hash" != "$EXPECTED_PATCHER_SHA256" ]; then
    abort "! SystemUI patch generator hash mismatch: $patcher_hash"
fi
if [ "$delta_hash" != "$EXPECTED_DELTA_SHA256" ]; then
    abort "! SystemUI delta hash mismatch: $delta_hash"
fi
chmod 0755 "$PATCHER" || abort "! SystemUI patch generator is not executable"

if [ ! -f "$BRIDGE_APK" ]; then
    abort "! SCR Overview payload is missing"
fi

bridge_hash=$(sha256sum "$BRIDGE_APK" 2>/dev/null | cut -d ' ' -f 1)
if [ "$bridge_hash" != "$EXPECTED_BRIDGE_SHA256" ]; then
    abort "! SCR Overview payload hash mismatch: $bridge_hash"
fi

single_package_path() {
    package_name=$1
    package_paths=$("$TIMEOUT" -k 1s 10s pm path "$package_name" 2>/dev/null) ||
        return 1
    package_path=
    package_count=0
    while IFS= read -r package_line; do
        case "$package_line" in
            package:*)
                package_candidate=${package_line#package:}
                [ -n "$package_candidate" ] || return 1
                package_count=$((package_count + 1))
                [ "$package_count" -eq 1 ] || return 1
                package_path=$package_candidate
                ;;
            "") ;;
            *) return 1 ;;
        esac
    done <<EOF
$package_paths
EOF
    [ "$package_count" -eq 1 ] && [ -n "$package_path" ] || return 1
    printf '%s\n' "$package_path"
}

installed_path=$(single_package_path "$BRIDGE_PACKAGE") || installed_path=
installed_hash=$(sha256sum "$installed_path" 2>/dev/null | cut -d ' ' -f 1)

restore_previous_bridge() {
    backup_apk=$1
    backup_hash=$2
    "$TIMEOUT" -k 2s 30s pm uninstall --user 0 "$BRIDGE_PACKAGE" \
        >/dev/null 2>&1 || true
    "$TIMEOUT" -k 2s 60s pm install "$backup_apk" \
        >/dev/null 2>&1 || return 1
    restored_path=$(single_package_path "$BRIDGE_PACKAGE") || return 1
    restored_hash=$(sha256sum "$restored_path" 2>/dev/null | cut -d ' ' -f 1)
    [ "$restored_hash" = "$backup_hash" ]
}

ui_print "- Verifying the signed SCR Overview bridge"
case "$installed_hash" in
    "$EXPECTED_BRIDGE_SHA256")
        ui_print "- Existing SCR Overview bridge already verified"
        ;;
    "$EXPECTED_BRIDGE_046_SHA256"|"$EXPECTED_BRIDGE_045_SHA256"|"$EXPECTED_BRIDGE_044_SHA256"|"$EXPECTED_BRIDGE_043_SHA256"|"$EXPECTED_BRIDGE_042_SHA256"|"$EXPECTED_BRIDGE_041_SHA256"|"$EXPECTED_BRIDGE_040_SHA256"|"$EXPECTED_BRIDGE_039_SHA256"|"$EXPECTED_BRIDGE_038_SHA256"|"$EXPECTED_BRIDGE_037_SHA256"|"$EXPECTED_BRIDGE_036_SHA256"|"$EXPECTED_BRIDGE_036_RC_SHA256"|"$EXPECTED_BRIDGE_035_SHA256"|"$EXPECTED_BRIDGE_034_SHA256"|"$EXPECTED_BRIDGE_033_SHA256"|"$EXPECTED_BRIDGE_032_SHA256"|"$EXPECTED_BRIDGE_020_SHA256"|"$EXPECTED_BRIDGE_021_SHA256"|"$EXPECTED_BRIDGE_022_SHA256"|"$EXPECTED_BRIDGE_023_SHA256"|"$EXPECTED_BRIDGE_024_SHA256"|"$EXPECTED_BRIDGE_025_SHA256"|"$EXPECTED_BRIDGE_026_SHA256"|"$EXPECTED_BRIDGE_027_SHA256"|"$EXPECTED_BRIDGE_028_SHA256"|"$EXPECTED_BRIDGE_030_SHA256"|"$EXPECTED_BRIDGE_031_RC_SHA256"|"$EXPECTED_BRIDGE_031_SHA256"|"")
        ui_print "- Installing the signed SCR Overview bridge"
        if ! "$TIMEOUT" -k 2s 60s pm install -r "$BRIDGE_APK" \
            >/dev/null 2>&1; then
            abort "! SCR Overview installation failed"
        fi
        ;;
    "$EXPECTED_BRIDGE_010_SHA256"|"$EXPECTED_BRIDGE_011_SHA256"|"$EXPECTED_BRIDGE_012_SHA256")
        ui_print "- Migrating the previous SCR Overview signing identity"
        legacy_hash=$installed_hash
        migration_backup="$MODPATH/.SCROverview.previous.$$"
        rm -f "$migration_backup"
        if ! "$TIMEOUT" -k 1s 15s cp "$installed_path" "$migration_backup" \
            >/dev/null 2>&1; then
            abort "! Previous SCR Overview backup failed"
        fi
        chmod 0600 "$migration_backup" || {
            rm -f "$migration_backup"
            abort "! Previous SCR Overview backup permissions failed"
        }
        migration_hash=$(sha256sum "$migration_backup" 2>/dev/null | cut -d ' ' -f 1)
        if [ "$migration_hash" != "$legacy_hash" ]; then
            rm -f "$migration_backup"
            abort "! Previous SCR Overview backup hash mismatch"
        fi
        if ! "$TIMEOUT" -k 2s 30s pm uninstall --user 0 "$BRIDGE_PACKAGE" \
            >/dev/null 2>&1; then
            rm -f "$migration_backup"
            abort "! Previous SCR Overview removal failed"
        fi
        if ! "$TIMEOUT" -k 2s 60s pm install "$BRIDGE_APK" \
            >/dev/null 2>&1; then
            if restore_previous_bridge "$migration_backup" "$legacy_hash"; then
                rm -f "$migration_backup"
                abort "! SCR Overview migration failed; previous version restored"
            fi
            rm -f "$migration_backup"
            abort "! SCR Overview migration and rollback failed"
        fi
        migrated_path=$(single_package_path "$BRIDGE_PACKAGE") || migrated_path=
        migrated_hash=$(sha256sum "$migrated_path" 2>/dev/null | cut -d ' ' -f 1)
        if [ "$migrated_hash" != "$EXPECTED_BRIDGE_SHA256" ]; then
            if restore_previous_bridge "$migration_backup" "$legacy_hash"; then
                rm -f "$migration_backup"
                abort "! Migrated SCR Overview verification failed; previous version restored"
            fi
            rm -f "$migration_backup"
            abort "! Migrated SCR Overview verification and rollback failed"
        fi
        rm -f "$migration_backup"
        ;;
    *)
        abort "! Unexpected SCR Overview package hash: $installed_hash"
        ;;
esac

installed_path=$(single_package_path "$BRIDGE_PACKAGE") || installed_path=
installed_hash=$(sha256sum "$installed_path" 2>/dev/null | cut -d ' ' -f 1)
if [ "$installed_hash" != "$EXPECTED_BRIDGE_SHA256" ]; then
    abort "! Installed SCR Overview hash mismatch: $installed_hash"
fi

ui_print "- Compatible SystemUI, verified delta and Overview bridge found"
ui_print "- The patched APK will be generated locally on this SCR-01"
