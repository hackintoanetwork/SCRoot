#!/system/bin/sh

TARGET_APK=/system/system_ext/priv-app/SystemUI/SystemUI.apk
SYSTEMUI_PACKAGE=com.android.systemui
NSENTER=/system/bin/nsenter
TIMEOUT=/system/bin/timeout
FLOCK=/system/bin/flock
MODDIR=${0%/*}
LOCK_FILE=/data/adb/.scr01_overview_bridge.activation.lock
EXPECTED_STOCK_SHA256=83d1cf22a48b864351c4e3fde0f6463f54806819d12b5abd5596275f7e2b6f20
EXPECTED_PATCH_SHA256=6814f34f7a382ed197b647294ccd166d78556431ec1cb3d914e2736837c6db14
UNMOUNTED=0
LOCK_HELD=0

acquire_activation_lock() {
    [ -x "$FLOCK" ] || return 1
    [ ! -L "$LOCK_FILE" ] || return 1
    [ ! -e "$LOCK_FILE" ] || [ -f "$LOCK_FILE" ] || return 1
    : >> "$LOCK_FILE" || return 1
    chmod 0600 "$LOCK_FILE" || return 1
    exec 0<> "$LOCK_FILE" || return 1
    count=0
    while ! "$FLOCK" -n 0; do
        count=$((count + 1))
        if [ "$count" -ge 1200 ]; then
            exec 0< /dev/null
            return 1
        fi
        sleep 0.1
    done
    LOCK_HELD=1
}

release_activation_lock() {
    if [ "$LOCK_HELD" = 1 ]; then
        "$FLOCK" -u 0 2>/dev/null || true
        exec 0< /dev/null
        LOCK_HELD=0
    fi
}

handle_uninstall_signal() {
    trap - HUP INT TERM
    exit 99
}

cleanup_on_exit() {
    cleanup_rc=$?
    trap - EXIT HUP INT TERM
    release_activation_lock
    exit "$cleanup_rc"
}

if ! acquire_activation_lock; then
    exit 90
fi
trap cleanup_on_exit EXIT
trap handle_uninstall_signal HUP INT TERM

stop_task_bridge() {
    task_bridge_pids="$(cat "$MODDIR/task-bridge.pid" 2>/dev/null) $(pidof scr01-task-bridge 2>/dev/null)"
    seen_task_bridge_pids=' '
    for task_bridge_pid in $task_bridge_pids; do
        case "$task_bridge_pid" in
            ''|*[!0-9]*) continue ;;
        esac
        case "$seen_task_bridge_pids" in
            *" $task_bridge_pid "*) continue ;;
        esac
        seen_task_bridge_pids="$seen_task_bridge_pids$task_bridge_pid "
        task_bridge_name=$({
            tr '\000' '\n' < "/proc/$task_bridge_pid/cmdline"
        } 2>/dev/null | sed -n '1p')
        if [ "$task_bridge_name" = 'scr01-task-bridge' ]; then
            kill -TERM "$task_bridge_pid" 2>/dev/null
            count=0
            while [ "$count" -lt 20 ] && kill -0 "$task_bridge_pid" 2>/dev/null; do
                sleep 0.1
                count=$((count + 1))
            done
            kill -KILL "$task_bridge_pid" 2>/dev/null || true
        fi
    done
    rm -f "$MODDIR/task-bridge.pid" "$MODDIR/task-bridge.ready"
}

systemui_pid() {
    systemui_pids=$(pidof "$SYSTEMUI_PACKAGE" 2>/dev/null)
    systemui_result=
    systemui_count=0
    for systemui_candidate in $systemui_pids; do
        case "$systemui_candidate" in
            ''|*[!0-9]*) continue ;;
        esac
        systemui_name=$({
            tr '\000' '\n' < "/proc/$systemui_candidate/cmdline"
        } 2>/dev/null | sed -n '1p')
        [ "$systemui_name" = "$SYSTEMUI_PACKAGE" ] || continue
        systemui_count=$((systemui_count + 1))
        [ "$systemui_count" -eq 1 ] || return 1
        systemui_result=$systemui_candidate
    done
    [ "$systemui_count" -eq 1 ] && [ -n "$systemui_result" ] || return 1
    printf '%s\n' "$systemui_result"
}

[ -x "$NSENTER" ] && [ -x "$TIMEOUT" ] || exit 91
mounted_hash=$(
    "$NSENTER" -t 1 -m -- "$TIMEOUT" -k 1s 15s \
        sha256sum "$TARGET_APK" 2>/dev/null | cut -d ' ' -f 1
)
case "$mounted_hash" in
    "$EXPECTED_PATCH_SHA256")
        if ! "$NSENTER" -t 1 -m -- "$TIMEOUT" -k 1s 10s \
            umount "$TARGET_APK" 2>/dev/null &&
            ! "$NSENTER" -t 1 -m -- "$TIMEOUT" -k 1s 10s \
                umount -l "$TARGET_APK" 2>/dev/null; then
            exit 92
        fi
        UNMOUNTED=1
        restored_hash=$(
            "$NSENTER" -t 1 -m -- "$TIMEOUT" -k 1s 15s \
                sha256sum "$TARGET_APK" 2>/dev/null | cut -d ' ' -f 1
        )
        [ "$restored_hash" = "$EXPECTED_STOCK_SHA256" ] || exit 93
        ;;
    "$EXPECTED_STOCK_SHA256") ;;
    "") exit 94 ;;
    *) exit 95 ;;
esac

stop_task_bridge
RESTART_REQUIRED=$UNMOUNTED
[ "$(getprop sys.boot_completed)" = 1 ] && RESTART_REQUIRED=1
if [ "$RESTART_REQUIRED" = 1 ]; then
    old_systemui_pid=$(systemui_pid) || old_systemui_pid=
    if [ -n "$old_systemui_pid" ]; then
        kill -TERM "$old_systemui_pid" 2>/dev/null || true
    fi
    count=0
    new_systemui_pid=
    while [ "$count" -lt 60 ]; do
        new_systemui_pid=$(systemui_pid) || new_systemui_pid=
        if [ -n "$new_systemui_pid" ] &&
            { [ -z "$old_systemui_pid" ] || [ "$new_systemui_pid" != "$old_systemui_pid" ]; }; then
            break
        fi
        sleep 0.25
        count=$((count + 1))
    done
    [ -n "$new_systemui_pid" ] &&
        { [ -z "$old_systemui_pid" ] || [ "$new_systemui_pid" != "$old_systemui_pid" ]; } || exit 96
fi

exit 0
